#include "edge.hpp"
#include "proj2.hpp"


int main()
{
	return 0;
}

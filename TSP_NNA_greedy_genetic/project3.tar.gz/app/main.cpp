#include <vector>
#include <iostream>
#include <string>
#include "proj3.hpp"

int main(int argc, char ** argv)
{

    return 0;
}

